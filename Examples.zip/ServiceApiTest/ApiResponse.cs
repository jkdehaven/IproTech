﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace ServiceApiTest
{
    class ApiResponse
    {
        public static List<String> errorList = new List<String>();
        ExecutorService executor;
        ChromeDriver driver;

        [Test]
        public void URLCheckTest()
        {
            int MyThreads = 30;
            executor = Executor.newFixedThreadPool(MyThreads);
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://iprotech.com/careers/");
        }
    }
}
