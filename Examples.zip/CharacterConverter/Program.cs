﻿using System;

namespace CSharpExamples
{
    class CharacterConverter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Converts all characters in a string from lowercase to uppercase and displays the converted string");
            Console.WriteLine("Enter a string: ");

            //Reads the string entered by the user
            string UserStr = Console.ReadLine();

            //Counts the length of the string
            int StrLength = UserStr.Length;

            //Puts the string into a character array to check each character for uppercase or lowercase
            char[] StrArray = UserStr.ToCharArray(0, StrLength);

            Console.WriteLine("You entered '" + UserStr + "' to be converted");
            Console.WriteLine("Here is the conversion: ");

            //This for loop will iterate through each character in the character array
            for (int i = 0; i < StrLength; i++)
            {
                char ArrayChar = StrArray[i];

                //This if statement will check each character if it is lowercase or uppercase

                if (Char.IsLower(ArrayChar)) //If it is lowercase
                {
                    Console.Write(Char.ToUpper(ArrayChar));//convert to uppercase
                }
                else
                {
                    Console.Write(ArrayChar);//leave it as 
                }
            }
            Console.Write("\n\n");

        }
    }
}





