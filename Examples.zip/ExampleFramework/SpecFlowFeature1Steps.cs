﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace ExampleFramework
{

    [Binding]
    public class SpecFlowFeature1Steps
    {
        private IWebDriver driver;

        [Given(@"I have navigated to IProWebsite")]
      public void GivenIHaveNavigatedToIProWebsite()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://iprotech.com/");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
        }

        [Given(@"the careers link will be present")]
        public void GivenTheCareersLinkWillBePresent()
        {
            var careerslink = driver.FindElement(By.LinkText("Careers")).Displayed;
            Assert.IsTrue(careerslink);

        }

        [When(@"I click the careers link")]
        public void WhenIClickTheCareersLink()
        {
            WebDriverWait CareersLink = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            CareersLink.Until(ExpectedConditions.ElementToBeClickable(By.LinkText("Careers")));
            driver.FindElement(By.LinkText("Careers")).Click();
        }
        
      

        [Then(@"The careers page will be present")]
        public void Thecareerspagewillbepresent()
        {
            Task.Delay(2500);
            var ExpectedCareersTitle = "Ipro Careers Mean Working and Playing Hard | Careers | Ipro Tech";
            var ActualCareersTitle = driver.Title;

            Assert.AreEqual(ExpectedCareersTitle, ActualCareersTitle);
            driver.Dispose();
            driver.Quit();

        }

    }
}
